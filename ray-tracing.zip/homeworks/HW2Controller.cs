
public class HW2Controller
{
    public static void Main() {
        Camera c = new Camera();

        c.RenderImage("test.bmp");
    }
}